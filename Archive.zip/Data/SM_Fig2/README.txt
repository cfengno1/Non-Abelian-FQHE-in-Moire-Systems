Energy spectra as a function of lambda at Ns=16, 24 and 28. 
1st col is theta or epsilon, 2nd-8th cols are the 7 lowest states at k0, 9th col is the lowest state energy at k1
