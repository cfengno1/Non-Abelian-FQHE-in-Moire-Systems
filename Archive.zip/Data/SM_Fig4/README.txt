Energy spectra for Ns=16,24,28 and 32.
1st col is kx+ky*Nx
