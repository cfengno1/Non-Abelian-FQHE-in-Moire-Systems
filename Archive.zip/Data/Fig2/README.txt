gap_N16ep5: spin gaps vs. Delta S for Ns=16.   Use $2-$3 for gaps.

gap_ep10 and gap_ep5: spin gap (Delta S=1) vs. N (number of site, 1st column) for epsilon=5 and 10. Use $2-$3 (2nd column - 3rd column) for the spin gap.
