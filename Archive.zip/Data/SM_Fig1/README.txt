Energy spectra at Ns=24,28 and lambda=0, 0.5

1st col is kx+ky*Nx
