For model B with Ns=28 and k=(0,1) or (7,0)
B_ph_all.dat: the Berry phase (3rd col) as a function of theta_x (1st col) and theta_y (2nd col)
