Model A at Ns=32
NkMA.dat: momentum space hole distribution 
SqMA.dat: density structure factor

1st col is kx; 2nd col is ky
