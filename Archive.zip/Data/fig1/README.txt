val.dat: Band structure for single-hole Hamiltonian Eq.(1) along G-M-K-G. The lowest 10 bands are stored
T_metric.dat: quantum metric trace condition of the second lowest Moire band as a function of V2 and theta

