Particle-cut entanglement spectrum by partitioning the Ns = 28 model B system into NA and Nh − NA particles. NA=3 or 4.
The 1st col is kx+ky*Nx. 2nd col is the entanglement spectrum
