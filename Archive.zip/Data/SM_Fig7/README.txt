Model B at Ns=28
NkNs28.dat: momentum space hole distribution 
SqNs28.dat: density structure factor

1st col is kx; 2nd col is ky
