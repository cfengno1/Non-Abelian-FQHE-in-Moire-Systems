Energy spectra for Ns=26 and 30.
1st col is kx+ky*Nx
