Many-body Energy Spectrum for different system sizes Ns and epsilon. The 1st col denotes the momentum kx+ky*Nx
